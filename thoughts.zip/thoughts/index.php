<?php get_header(); ?>

	<?php get_template_part('loop-collapsed'); ?>

	<?php get_template_part('pagination'); ?>

<?php get_footer(); ?>
